# Forge Growth on Windows — v1.0.0

Everything in this folder is what you need. Nothing else to download.

**These are shell scripts, so they run inside WSL2 — not in PowerShell.**
There is no PowerShell or .bat installer.

## 1. Turn on WSL2

In **PowerShell as Administrator**, then reboot:

```powershell
wsl --install
```

## 2. Install Docker Desktop

https://docs.docker.com/desktop/install/windows-install/

Then turn on **Settings → Resources → WSL integration** for your distro.

## 3. Copy this folder into Linux, not the C: drive

Open the **Ubuntu** terminal from the Start menu and run everything from there.
Copy this folder into your Linux home first — the Windows drive is dramatically
slower and confuses file-watching:

```bash
cp -r /mnt/c/Users/<you>/Downloads/forge-growth-v1.0.0/windows ~/forge-growth
cd ~/forge-growth
```

Check Docker is reachable — this must print a version:

```bash
docker compose version
```

## 4. Install Forge Growth

```bash
chmod +x *.sh
./install.sh
```

The `chmod` matters here: unzipping on Windows drops the executable bit.

It asks one question — the address people will use — generates every secret, and
**prints the admin password once**. Write it down.

## 5. Afterwards

```bash
./up.sh          # start — and check the URL really answers
./down.sh        # stop, keeping all data
./install.sh     # upgrade
```

Open the folder from Explorer with `explorer.exe .`, or browse to
\\wsl$\Ubuntu\home\<you>\forge-growth

Next: attach a WhatsApp number.
https://github.com/Forgemind-git/ForgeGrowth-OSS/blob/main/docs/whatsapp.md
