# Forge Growth on macOS — v1.0.0

Everything in this folder is what you need. Nothing else to download.

**Apple Silicon and Intel both run natively** — nothing is emulated.

## 1. Install Docker Desktop

https://docs.docker.com/desktop/install/mac-install/ — or OrbStack, or Colima.
All three work.

Start it and wait for the whale icon to stop animating. Then, in **Terminal**,
check it works — this must print a version:

```bash
docker compose version
```

## 2. Install Forge Growth

In Terminal, `cd` into **this folder** (drag the folder onto the Terminal window
after typing `cd ` to fill in the path):

```bash
chmod +x *.sh
./install.sh
```

It asks one question — the address people will use — generates every secret, and
**prints the admin password once**. Write it down.

On a laptop, take the default. It serves on http://localhost:8080, or the next
free port, which it tells you.

## 3. Afterwards

```bash
./up.sh          # start — and check the URL really answers
./down.sh        # stop, keeping all data
./install.sh     # upgrade
```

Next: attach a WhatsApp number. On a laptop this needs a public HTTPS address
from a tunnel — the guide covers it.
https://github.com/Forgemind-git/ForgeGrowth-OSS/blob/main/docs/whatsapp.md
