# Forge Growth on Linux — v1.0.0

Everything in this folder is what you need. Nothing else to download.

## 1. Install Docker

Docker Engine **with the Compose v2 plugin**: https://docs.docker.com/engine/install/

Let your user reach Docker without `sudo`, then **log out and back in**:

```bash
sudo usermod -aG docker $USER
```

Check it works — this must print a version:

```bash
docker compose version
```

## 2. Install Forge Growth

From **inside this folder**:

```bash
chmod +x *.sh
./install.sh
```

It asks one question — the address people will use — generates every secret, and
**prints the admin password once**. Write it down.

On a server with a domain, ask nothing at all:

```bash
./install.sh --domain crm.example.com
```

Point the domain's DNS at this machine first, and leave ports 80 and 443 free.
A Let's Encrypt certificate is obtained and verified on the way up.

## 3. Afterwards

```bash
./up.sh          # start — and check the public URL really answers
./down.sh        # stop, keeping all data
./install.sh     # upgrade
```

Next: attach a WhatsApp number.
https://github.com/Forgemind-git/ForgeGrowth-OSS/blob/main/docs/whatsapp.md
